from .truth_table_plus import truth_table_plus
