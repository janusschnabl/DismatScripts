## VI BESTÅRRRR LÅ LÅ LÅ LÅ

♫ Brøndby er vores liv,
der er ingen tvivl,
samlet vil vi stå,
om vor fælles mål,
kun for gul og blå. 🟦🟨 ♫

♫ Ole ole ole ole ♫

♫ Ligemeget hvor I er,
vil vi følge jer,
kom nu alle mand,
syng så højt I kan,
Brøndbys tolvte mand. ♫

♫ Ole ole ole ole ♫
