from sympy import sympify, latex, init_printing, true
from sympy.logic.boolalg import truth_table

init_printing()
from IPython.display import (
    Latex,
    display,
)


def truth_table_plus(expr, variables, input=True):
    variables = [sympify(v) for v in variables]
    expr = sympify(expr)

    t_gen = truth_table(expr, variables, input)

    T = "\\mathbf{T}"
    F = "\\mathbf{F}"
    bool_tuple = (F, T)

    latex_table = "\\begin{array}{ |" + ("c|" * len(variables)) + "c| }\\hline "
    latex_rows = [" & ".join([latex(v) for v in variables] + [latex(expr)])]

    for t in t_gen:
        latex_rows.insert(
            1,
            " & ".join(
                [bool_tuple[var_val] for var_val in t[0]] + [T if t[1] is true else F]
            ),
        )

    latex_table += "\\\\ \\hline ".join(latex_rows)
    latex_table += "\\\\ \\hline \\end{array}"
    display(Latex(latex_table))
